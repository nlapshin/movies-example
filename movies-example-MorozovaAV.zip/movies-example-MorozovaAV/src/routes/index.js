import movie from './movie/index.js'

export default {
  register(app) {
    movie.register(app)
  }
}
