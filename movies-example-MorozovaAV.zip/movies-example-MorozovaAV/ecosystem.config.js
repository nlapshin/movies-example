export default {
  apps : [{
    name   : "movie",
    script : "./src/index.js"
  }]
}
